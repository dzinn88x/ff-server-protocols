﻿using System;
using System.Runtime.InteropServices;
using Il2CppDummyDll;

namespace <PrivateImplementationDetails>{A73646B4-D586-485A-BF94-04F4277E92F7}
{
	// Token: 0x02002C22 RID: 11298
	[Token(Token = "0x2002C22")]
	[StructLayout(3, CharSet = CharSet.Auto)]
	public class __BB_OBFUSCATOR_VERSION_1_26_0
	{
	}
}
