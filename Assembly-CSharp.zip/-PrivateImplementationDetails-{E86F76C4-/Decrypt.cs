﻿using System;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using Mono.Math;

namespace <PrivateImplementationDetails>{E86F76C4-9778-4658-B201-54B6FB30AE1A}LOkWPANW
{
	// Token: 0x02002C1F RID: 11295
	[Token(Token = "0x2002C1F")]
	[StructLayout(3, CharSet = CharSet.Auto)]
	public class Decrypt
	{
		// Token: 0x0600F94B RID: 63819 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x600F94B")]
		[Address(RVA = "0x1F824CC", Offset = "0x1F824CC", VA = "0x7BBC7824CC")]
		public Decrypt()
		{
		}

		// Token: 0x0600F94D RID: 63821 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x600F94D")]
		[Address(RVA = "0x1F8269C", Offset = "0x1F8269C", VA = "0x7BBC78269C")]
		private static string Translate(byte[] b)
		{
			return null;
		}

		// Token: 0x0600F94E RID: 63822 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x600F94E")]
		[Address(RVA = "0x1F827C0", Offset = "0x1F827C0", VA = "0x7BBC7827C0")]
		public static string DecryptLiteral(byte[] bytes, bool stripTokens)
		{
			return null;
		}

		// Token: 0x04011D8F RID: 73103
		[Token(Token = "0x4011D8F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private static byte[] publicKey;

		// Token: 0x04011D90 RID: 73104
		[Token(Token = "0x4011D90")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
		private static int blockLengthField;

		// Token: 0x04011D91 RID: 73105
		[Token(Token = "0x4011D91")]
		[Il2CppDummyDll.FieldOffset(Offset = "0xC")]
		private static int exponentField;

		// Token: 0x04011D92 RID: 73106
		[Token(Token = "0x4011D92")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		private static BigInteger nField;
	}
}
