﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace AmplifyColor
{
	// Token: 0x0200042E RID: 1070
	[Token(Token = "0x200042E")]
	[Serializable]
	public class VolumeEffectContainer
	{
		// Token: 0x06001BC3 RID: 7107 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BC3")]
		[Address(RVA = "0x1F87494", Offset = "0x1F87494", VA = "0x7BBC787494")]
		public VolumeEffectContainer()
		{
		}

		// Token: 0x06001BC4 RID: 7108 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BC4")]
		[Address(RVA = "0x1F87508", Offset = "0x1F87508", VA = "0x7BBC787508")]
		public void AddColorEffect(PostEffectManagerBase colorEffect)
		{
		}

		// Token: 0x06001BC5 RID: 7109 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BC5")]
		[Address(RVA = "0x1F877E4", Offset = "0x1F877E4", VA = "0x7BBC7877E4")]
		public VolumeEffect AddJustColorEffect(PostEffectManagerBase colorEffect)
		{
			return null;
		}

		// Token: 0x06001BC6 RID: 7110 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BC6")]
		[Address(RVA = "0x1F875B8", Offset = "0x1F875B8", VA = "0x7BBC7875B8")]
		public VolumeEffect FindVolumeEffect(PostEffectManagerBase colorEffect)
		{
			return null;
		}

		// Token: 0x06001BC7 RID: 7111 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BC7")]
		[Address(RVA = "0x1F87878", Offset = "0x1F87878", VA = "0x7BBC787878")]
		public void RemoveVolumeEffect(VolumeEffect volume)
		{
		}

		// Token: 0x06001BC8 RID: 7112 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BC8")]
		[Address(RVA = "0x1F878E8", Offset = "0x1F878E8", VA = "0x7BBC7878E8")]
		public PostEffectManagerBase[] GetStoredEffects()
		{
			return null;
		}

		// Token: 0x04001436 RID: 5174
		[Token(Token = "0x4001436")]
		[FieldOffset(Offset = "0x10")]
		public List<VolumeEffect> volumes;

		// Token: 0x0200042F RID: 1071
		[Token(Token = "0x200042F")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E304C", Offset = "0x10E304C")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06001BCA RID: 7114 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BCA")]
			[Address(RVA = "0x1F87A4C", Offset = "0x1F87A4C", VA = "0x7BBC787A4C")]
			public <>c()
			{
			}

			// Token: 0x06001BCB RID: 7115 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6001BCB")]
			[Address(RVA = "0x1F87A54", Offset = "0x1F87A54", VA = "0x7BBC787A54")]
			internal PostEffectManagerBase <GetStoredEffects>b__6_0(VolumeEffect r)
			{
				return null;
			}

			// Token: 0x04001437 RID: 5175
			[Token(Token = "0x4001437")]
			[FieldOffset(Offset = "0x0")]
			public static readonly VolumeEffectContainer.<>c <>9;

			// Token: 0x04001438 RID: 5176
			[Token(Token = "0x4001438")]
			[FieldOffset(Offset = "0x8")]
			public static Func<VolumeEffect, PostEffectManagerBase> <>9__6_0;
		}
	}
}
