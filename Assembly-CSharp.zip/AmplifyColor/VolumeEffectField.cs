﻿using System;
using System.Reflection;
using Il2CppDummyDll;
using UnityEngine;

namespace AmplifyColor
{
	// Token: 0x02000428 RID: 1064
	[Token(Token = "0x2000428")]
	[Serializable]
	public class VolumeEffectField
	{
		// Token: 0x06001BA2 RID: 7074 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BA2")]
		[Address(RVA = "0x1F8465C", Offset = "0x1F8465C", VA = "0x7BBC78465C")]
		public VolumeEffectField(string fieldName, string fieldType)
		{
		}

		// Token: 0x06001BA3 RID: 7075 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BA3")]
		[Address(RVA = "0x1F86324", Offset = "0x1F86324", VA = "0x7BBC786324")]
		public VolumeEffectField(FieldInfo pi, Component c)
		{
		}

		// Token: 0x06001BA4 RID: 7076 RVA: 0x0000BCB8 File Offset: 0x00009EB8
		[Token(Token = "0x6001BA4")]
		[Address(RVA = "0x1F86234", Offset = "0x1F86234", VA = "0x7BBC786234")]
		public static bool IsValidType(string type)
		{
			return default(bool);
		}

		// Token: 0x06001BA5 RID: 7077 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BA5")]
		[Address(RVA = "0x1F87A80", Offset = "0x1F87A80", VA = "0x7BBC787A80")]
		public void UpdateValue(object val)
		{
		}

		// Token: 0x04001423 RID: 5155
		[Token(Token = "0x4001423")]
		[FieldOffset(Offset = "0x10")]
		public string fieldName;

		// Token: 0x04001424 RID: 5156
		[Token(Token = "0x4001424")]
		[FieldOffset(Offset = "0x18")]
		public string fieldType;

		// Token: 0x04001425 RID: 5157
		[Token(Token = "0x4001425")]
		[FieldOffset(Offset = "0x20")]
		public float valueSingle;

		// Token: 0x04001426 RID: 5158
		[Token(Token = "0x4001426")]
		[FieldOffset(Offset = "0x24")]
		public Color valueColor;

		// Token: 0x04001427 RID: 5159
		[Token(Token = "0x4001427")]
		[FieldOffset(Offset = "0x34")]
		public bool valueBoolean;

		// Token: 0x04001428 RID: 5160
		[Token(Token = "0x4001428")]
		[FieldOffset(Offset = "0x38")]
		public Vector2 valueVector2;

		// Token: 0x04001429 RID: 5161
		[Token(Token = "0x4001429")]
		[FieldOffset(Offset = "0x40")]
		public Vector3 valueVector3;

		// Token: 0x0400142A RID: 5162
		[Token(Token = "0x400142A")]
		[FieldOffset(Offset = "0x4C")]
		public Vector4 valueVector4;
	}
}
