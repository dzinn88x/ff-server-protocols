﻿using System;
using Il2CppDummyDll;

namespace AmplifyColor
{
	// Token: 0x02000426 RID: 1062
	[Token(Token = "0x2000426")]
	public enum EffectType
	{
		// Token: 0x04001411 RID: 5137
		[Token(Token = "0x4001411")]
		FastSSAO,
		// Token: 0x04001412 RID: 5138
		[Token(Token = "0x4001412")]
		ColorGrading,
		// Token: 0x04001413 RID: 5139
		[Token(Token = "0x4001413")]
		DepthBlur,
		// Token: 0x04001414 RID: 5140
		[Token(Token = "0x4001414")]
		Bloom,
		// Token: 0x04001415 RID: 5141
		[Token(Token = "0x4001415")]
		ACES,
		// Token: 0x04001416 RID: 5142
		[Token(Token = "0x4001416")]
		RimLighting,
		// Token: 0x04001417 RID: 5143
		[Token(Token = "0x4001417")]
		Fog,
		// Token: 0x04001418 RID: 5144
		[Token(Token = "0x4001418")]
		LinearToGamma,
		// Token: 0x04001419 RID: 5145
		[Token(Token = "0x4001419")]
		HDR,
		// Token: 0x0400141A RID: 5146
		[Token(Token = "0x400141A")]
		Max
	}
}
