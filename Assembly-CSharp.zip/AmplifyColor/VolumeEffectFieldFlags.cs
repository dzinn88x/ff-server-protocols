﻿using System;
using System.Reflection;
using Il2CppDummyDll;

namespace AmplifyColor
{
	// Token: 0x02000430 RID: 1072
	[Token(Token = "0x2000430")]
	[Serializable]
	public class VolumeEffectFieldFlags
	{
		// Token: 0x06001BCC RID: 7116 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BCC")]
		[Address(RVA = "0x1F86C78", Offset = "0x1F86C78", VA = "0x7BBC786C78")]
		public VolumeEffectFieldFlags(FieldInfo pi)
		{
		}

		// Token: 0x06001BCD RID: 7117 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BCD")]
		[Address(RVA = "0x1F86A84", Offset = "0x1F86A84", VA = "0x7BBC786A84")]
		public VolumeEffectFieldFlags(VolumeEffectField field)
		{
		}

		// Token: 0x04001439 RID: 5177
		[Token(Token = "0x4001439")]
		[FieldOffset(Offset = "0x10")]
		public string fieldName;

		// Token: 0x0400143A RID: 5178
		[Token(Token = "0x400143A")]
		[FieldOffset(Offset = "0x18")]
		public string fieldType;

		// Token: 0x0400143B RID: 5179
		[Token(Token = "0x400143B")]
		[FieldOffset(Offset = "0x20")]
		public bool blendFlag;
	}
}
