﻿using System;
using Il2CppDummyDll;

namespace AmplifyColor
{
	// Token: 0x02000425 RID: 1061
	[Token(Token = "0x2000425")]
	public enum Tonemapping
	{
		// Token: 0x0400140C RID: 5132
		[Token(Token = "0x400140C")]
		Disabled,
		// Token: 0x0400140D RID: 5133
		[Token(Token = "0x400140D")]
		Photographic,
		// Token: 0x0400140E RID: 5134
		[Token(Token = "0x400140E")]
		FilmicHable,
		// Token: 0x0400140F RID: 5135
		[Token(Token = "0x400140F")]
		FilmicACES
	}
}
