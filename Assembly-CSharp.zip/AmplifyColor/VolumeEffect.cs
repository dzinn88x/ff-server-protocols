﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace AmplifyColor
{
	// Token: 0x0200042C RID: 1068
	[Token(Token = "0x200042C")]
	[Serializable]
	public class VolumeEffect
	{
		// Token: 0x06001BB5 RID: 7093 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BB5")]
		[Address(RVA = "0x1F83B48", Offset = "0x1F83B48", VA = "0x7BBC783B48")]
		public VolumeEffect(PostEffectManagerBase effect)
		{
		}

		// Token: 0x06001BB6 RID: 7094 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BB6")]
		[Address(RVA = "0x1F83BCC", Offset = "0x1F83BCC", VA = "0x7BBC783BCC")]
		public static VolumeEffect BlendValuesToVolumeEffect(VolumeEffectFlags flags, VolumeEffect volume1, VolumeEffect volume2, float blend)
		{
			return null;
		}

		// Token: 0x06001BB7 RID: 7095 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BB7")]
		[Address(RVA = "0x1F84694", Offset = "0x1F84694", VA = "0x7BBC784694")]
		public VolumeEffectComponent AddComponent(Component c, VolumeEffectComponentFlags compFlags)
		{
			return null;
		}

		// Token: 0x06001BB8 RID: 7096 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BB8")]
		[Address(RVA = "0x1F84D70", Offset = "0x1F84D70", VA = "0x7BBC784D70")]
		public void RemoveEffectComponent(VolumeEffectComponent comp)
		{
		}

		// Token: 0x06001BB9 RID: 7097 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BB9")]
		[Address(RVA = "0x1F84DE0", Offset = "0x1F84DE0", VA = "0x7BBC784DE0")]
		public void UpdateVolume()
		{
		}

		// Token: 0x06001BBA RID: 7098 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BBA")]
		[Address(RVA = "0x1F84FDC", Offset = "0x1F84FDC", VA = "0x7BBC784FDC")]
		public void SetValues(PostEffectManagerBase targetColor)
		{
		}

		// Token: 0x06001BBB RID: 7099 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BBB")]
		[Address(RVA = "0x1F85690", Offset = "0x1F85690", VA = "0x7BBC785690")]
		public void BlendValues(PostEffectManagerBase targetColor, VolumeEffect other, float blendAmount)
		{
		}

		// Token: 0x06001BBC RID: 7100 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BBC")]
		[Address(RVA = "0x1F843E0", Offset = "0x1F843E0", VA = "0x7BBC7843E0")]
		public VolumeEffectComponent FindEffectComponent(string compName)
		{
			return null;
		}

		// Token: 0x06001BBD RID: 7101 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BBD")]
		[Address(RVA = "0x1F85C54", Offset = "0x1F85C54", VA = "0x7BBC785C54")]
		public static Component[] ListAcceptableComponents(PostEffectManagerBase go)
		{
			return null;
		}

		// Token: 0x06001BBE RID: 7102 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BBE")]
		[Address(RVA = "0x1F85E04", Offset = "0x1F85E04", VA = "0x7BBC785E04")]
		public string[] GetComponentNames()
		{
			return null;
		}

		// Token: 0x04001431 RID: 5169
		[Token(Token = "0x4001431")]
		[FieldOffset(Offset = "0x10")]
		public PostEffectManagerBase gameObject;

		// Token: 0x04001432 RID: 5170
		[Token(Token = "0x4001432")]
		[FieldOffset(Offset = "0x18")]
		public List<VolumeEffectComponent> components;

		// Token: 0x0200042D RID: 1069
		[Token(Token = "0x200042D")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E303C", Offset = "0x10E303C")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06001BC0 RID: 7104 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BC0")]
			[Address(RVA = "0x1F85F68", Offset = "0x1F85F68", VA = "0x7BBC785F68")]
			public <>c()
			{
			}

			// Token: 0x06001BC1 RID: 7105 RVA: 0x0000BD00 File Offset: 0x00009F00
			[Token(Token = "0x6001BC1")]
			[Address(RVA = "0x1F85F70", Offset = "0x1F85F70", VA = "0x7BBC785F70")]
			internal bool <ListAcceptableComponents>b__10_0(Component comp)
			{
				return default(bool);
			}

			// Token: 0x06001BC2 RID: 7106 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6001BC2")]
			[Address(RVA = "0x1F860A4", Offset = "0x1F860A4", VA = "0x7BBC7860A4")]
			internal string <GetComponentNames>b__11_0(VolumeEffectComponent r)
			{
				return null;
			}

			// Token: 0x04001433 RID: 5171
			[Token(Token = "0x4001433")]
			[FieldOffset(Offset = "0x0")]
			public static readonly VolumeEffect.<>c <>9;

			// Token: 0x04001434 RID: 5172
			[Token(Token = "0x4001434")]
			[FieldOffset(Offset = "0x8")]
			public static Func<Component, bool> <>9__10_0;

			// Token: 0x04001435 RID: 5173
			[Token(Token = "0x4001435")]
			[FieldOffset(Offset = "0x10")]
			public static Func<VolumeEffectComponent, string> <>9__11_0;
		}
	}
}
