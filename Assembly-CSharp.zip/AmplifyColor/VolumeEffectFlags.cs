﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace AmplifyColor
{
	// Token: 0x02000435 RID: 1077
	[Token(Token = "0x2000435")]
	[Serializable]
	public class VolumeEffectFlags
	{
		// Token: 0x06001BDC RID: 7132 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BDC")]
		[Address(RVA = "0x1F87C5C", Offset = "0x1F87C5C", VA = "0x7BBC787C5C")]
		public VolumeEffectFlags()
		{
		}

		// Token: 0x06001BDD RID: 7133 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BDD")]
		[Address(RVA = "0x1F87CD0", Offset = "0x1F87CD0", VA = "0x7BBC787CD0")]
		public void AddComponent(Component c)
		{
		}

		// Token: 0x06001BDE RID: 7134 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BDE")]
		[Address(RVA = "0x1F87E08", Offset = "0x1F87E08", VA = "0x7BBC787E08")]
		public void UpdateFlags(VolumeEffect effectVol)
		{
		}

		// Token: 0x06001BDF RID: 7135 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BDF")]
		[Address(RVA = "0x1F88060", Offset = "0x1F88060", VA = "0x7BBC788060")]
		public static void UpdateCamFlags(PostEffectManagerBase[] effects, AmplifyColorVolumeBase[] volumes)
		{
		}

		// Token: 0x06001BE0 RID: 7136 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BE0")]
		[Address(RVA = "0x1F881CC", Offset = "0x1F881CC", VA = "0x7BBC7881CC")]
		public VolumeEffect GenerateEffectData(PostEffectManagerBase go)
		{
			return null;
		}

		// Token: 0x06001BE1 RID: 7137 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BE1")]
		[Address(RVA = "0x1F883A4", Offset = "0x1F883A4", VA = "0x7BBC7883A4")]
		public VolumeEffectComponentFlags FindComponentFlags(string compName)
		{
			return null;
		}

		// Token: 0x06001BE2 RID: 7138 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BE2")]
		[Address(RVA = "0x1F884A0", Offset = "0x1F884A0", VA = "0x7BBC7884A0")]
		public string[] GetComponentNames()
		{
			return null;
		}

		// Token: 0x04001444 RID: 5188
		[Token(Token = "0x4001444")]
		[FieldOffset(Offset = "0x10")]
		public List<VolumeEffectComponentFlags> components;

		// Token: 0x02000436 RID: 1078
		[Token(Token = "0x2000436")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E308C", Offset = "0x10E308C")]
		private sealed class <>c__DisplayClass2_0
		{
			// Token: 0x06001BE3 RID: 7139 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BE3")]
			[Address(RVA = "0x1F87E00", Offset = "0x1F87E00", VA = "0x7BBC787E00")]
			public <>c__DisplayClass2_0()
			{
			}

			// Token: 0x06001BE4 RID: 7140 RVA: 0x0000BD60 File Offset: 0x00009F60
			[Token(Token = "0x6001BE4")]
			[Address(RVA = "0x1F88710", Offset = "0x1F88710", VA = "0x7BBC788710")]
			internal bool <AddComponent>b__0(VolumeEffectComponentFlags s)
			{
				return default(bool);
			}

			// Token: 0x04001445 RID: 5189
			[Token(Token = "0x4001445")]
			[FieldOffset(Offset = "0x10")]
			public Component c;
		}

		// Token: 0x02000437 RID: 1079
		[Token(Token = "0x2000437")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E309C", Offset = "0x10E309C")]
		private sealed class <>c__DisplayClass3_0
		{
			// Token: 0x06001BE5 RID: 7141 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BE5")]
			[Address(RVA = "0x1F88058", Offset = "0x1F88058", VA = "0x7BBC788058")]
			public <>c__DisplayClass3_0()
			{
			}

			// Token: 0x06001BE6 RID: 7142 RVA: 0x0000BD78 File Offset: 0x00009F78
			[Token(Token = "0x6001BE6")]
			[Address(RVA = "0x1F88770", Offset = "0x1F88770", VA = "0x7BBC788770")]
			internal bool <UpdateFlags>b__0(VolumeEffectComponentFlags s)
			{
				return default(bool);
			}

			// Token: 0x04001446 RID: 5190
			[Token(Token = "0x4001446")]
			[FieldOffset(Offset = "0x10")]
			public VolumeEffectComponent comp;
		}

		// Token: 0x02000438 RID: 1080
		[Token(Token = "0x2000438")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E30AC", Offset = "0x10E30AC")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06001BE8 RID: 7144 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BE8")]
			[Address(RVA = "0x1F886B0", Offset = "0x1F886B0", VA = "0x7BBC7886B0")]
			public <>c()
			{
			}

			// Token: 0x06001BE9 RID: 7145 RVA: 0x0000BD90 File Offset: 0x00009F90
			[Token(Token = "0x6001BE9")]
			[Address(RVA = "0x1F886B8", Offset = "0x1F886B8", VA = "0x7BBC7886B8")]
			internal bool <GetComponentNames>b__7_0(VolumeEffectComponentFlags r)
			{
				return default(bool);
			}

			// Token: 0x06001BEA RID: 7146 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6001BEA")]
			[Address(RVA = "0x1F886E4", Offset = "0x1F886E4", VA = "0x7BBC7886E4")]
			internal string <GetComponentNames>b__7_1(VolumeEffectComponentFlags r)
			{
				return null;
			}

			// Token: 0x04001447 RID: 5191
			[Token(Token = "0x4001447")]
			[FieldOffset(Offset = "0x0")]
			public static readonly VolumeEffectFlags.<>c <>9;

			// Token: 0x04001448 RID: 5192
			[Token(Token = "0x4001448")]
			[FieldOffset(Offset = "0x8")]
			public static Func<VolumeEffectComponentFlags, bool> <>9__7_0;

			// Token: 0x04001449 RID: 5193
			[Token(Token = "0x4001449")]
			[FieldOffset(Offset = "0x10")]
			public static Func<VolumeEffectComponentFlags, string> <>9__7_1;
		}
	}
}
