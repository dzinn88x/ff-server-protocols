﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace AmplifyColor
{
	// Token: 0x02000427 RID: 1063
	[Token(Token = "0x2000427")]
	[Serializable]
	public class VersionInfo
	{
		// Token: 0x06001B9A RID: 7066 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001B9A")]
		[Address(RVA = "0x1F83778", Offset = "0x1F83778", VA = "0x7BBC783778")]
		public static string StaticToString()
		{
			return null;
		}

		// Token: 0x06001B9B RID: 7067 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001B9B")]
		[Address(RVA = "0x1F83870", Offset = "0x1F83870", VA = "0x7BBC783870", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x17000333 RID: 819
		// (get) Token: 0x06001B9C RID: 7068 RVA: 0x0000BC88 File Offset: 0x00009E88
		[Token(Token = "0x17000333")]
		public int Number
		{
			[Token(Token = "0x6001B9C")]
			[Address(RVA = "0x1F83970", Offset = "0x1F83970", VA = "0x7BBC783970")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06001B9D RID: 7069 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001B9D")]
		[Address(RVA = "0x1F83990", Offset = "0x1F83990", VA = "0x7BBC783990")]
		private VersionInfo()
		{
		}

		// Token: 0x06001B9E RID: 7070 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001B9E")]
		[Address(RVA = "0x1F839C8", Offset = "0x1F839C8", VA = "0x7BBC7839C8")]
		private VersionInfo(byte major, byte minor, byte release)
		{
		}

		// Token: 0x06001B9F RID: 7071 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001B9F")]
		[Address(RVA = "0x1F83A14", Offset = "0x1F83A14", VA = "0x7BBC783A14")]
		public static VersionInfo Current()
		{
			return null;
		}

		// Token: 0x06001BA0 RID: 7072 RVA: 0x0000BCA0 File Offset: 0x00009EA0
		[Token(Token = "0x6001BA0")]
		[Address(RVA = "0x1F83A84", Offset = "0x1F83A84", VA = "0x7BBC783A84")]
		public static bool Matches(VersionInfo version)
		{
			return default(bool);
		}

		// Token: 0x0400141B RID: 5147
		[Token(Token = "0x400141B")]
		public const byte Major = 1;

		// Token: 0x0400141C RID: 5148
		[Token(Token = "0x400141C")]
		public const byte Minor = 6;

		// Token: 0x0400141D RID: 5149
		[Token(Token = "0x400141D")]
		public const byte Release = 6;

		// Token: 0x0400141E RID: 5150
		[Token(Token = "0x400141E")]
		[FieldOffset(Offset = "0x0")]
		private static string StageSuffix;

		// Token: 0x0400141F RID: 5151
		[Token(Token = "0x400141F")]
		[FieldOffset(Offset = "0x8")]
		private static string TrialSuffix;

		// Token: 0x04001420 RID: 5152
		[Token(Token = "0x4001420")]
		[FieldOffset(Offset = "0x10")]
		[SerializeField]
		private int m_major;

		// Token: 0x04001421 RID: 5153
		[Token(Token = "0x4001421")]
		[FieldOffset(Offset = "0x14")]
		[SerializeField]
		private int m_minor;

		// Token: 0x04001422 RID: 5154
		[Token(Token = "0x4001422")]
		[FieldOffset(Offset = "0x18")]
		[SerializeField]
		private int m_release;
	}
}
