﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Il2CppDummyDll;
using UnityEngine;

namespace AmplifyColor
{
	// Token: 0x02000431 RID: 1073
	[Token(Token = "0x2000431")]
	[Serializable]
	public class VolumeEffectComponentFlags
	{
		// Token: 0x06001BCE RID: 7118 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BCE")]
		[Address(RVA = "0x1F8682C", Offset = "0x1F8682C", VA = "0x7BBC78682C")]
		public VolumeEffectComponentFlags(string name)
		{
		}

		// Token: 0x06001BCF RID: 7119 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BCF")]
		[Address(RVA = "0x1F868B0", Offset = "0x1F868B0", VA = "0x7BBC7868B0")]
		public VolumeEffectComponentFlags(VolumeEffectComponent comp)
		{
		}

		// Token: 0x06001BD0 RID: 7120 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BD0")]
		[Address(RVA = "0x1F86AE8", Offset = "0x1F86AE8", VA = "0x7BBC786AE8")]
		public VolumeEffectComponentFlags(Component c)
		{
		}

		// Token: 0x06001BD1 RID: 7121 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BD1")]
		[Address(RVA = "0x1F86D04", Offset = "0x1F86D04", VA = "0x7BBC786D04")]
		public void UpdateComponentFlags(VolumeEffectComponent comp)
		{
		}

		// Token: 0x06001BD2 RID: 7122 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BD2")]
		[Address(RVA = "0x1F86F70", Offset = "0x1F86F70", VA = "0x7BBC786F70")]
		public void UpdateComponentFlags(Component c)
		{
		}

		// Token: 0x06001BD3 RID: 7123 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BD3")]
		[Address(RVA = "0x1F8717C", Offset = "0x1F8717C", VA = "0x7BBC78717C")]
		public string[] GetFieldNames()
		{
			return null;
		}

		// Token: 0x0400143C RID: 5180
		[Token(Token = "0x400143C")]
		[FieldOffset(Offset = "0x10")]
		public string componentName;

		// Token: 0x0400143D RID: 5181
		[Token(Token = "0x400143D")]
		[FieldOffset(Offset = "0x18")]
		public List<VolumeEffectFieldFlags> componentFields;

		// Token: 0x0400143E RID: 5182
		[Token(Token = "0x400143E")]
		[FieldOffset(Offset = "0x20")]
		public bool blendFlag;

		// Token: 0x02000432 RID: 1074
		[Token(Token = "0x2000432")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E305C", Offset = "0x10E305C")]
		private sealed class <>c__DisplayClass6_0
		{
			// Token: 0x06001BD4 RID: 7124 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BD4")]
			[Address(RVA = "0x1F86F68", Offset = "0x1F86F68", VA = "0x7BBC786F68")]
			public <>c__DisplayClass6_0()
			{
			}

			// Token: 0x06001BD5 RID: 7125 RVA: 0x0000BD18 File Offset: 0x00009F18
			[Token(Token = "0x6001BD5")]
			[Address(RVA = "0x1F873EC", Offset = "0x1F873EC", VA = "0x7BBC7873EC")]
			internal bool <UpdateComponentFlags>b__0(VolumeEffectFieldFlags s)
			{
				return default(bool);
			}

			// Token: 0x0400143F RID: 5183
			[Token(Token = "0x400143F")]
			[FieldOffset(Offset = "0x10")]
			public VolumeEffectField field;
		}

		// Token: 0x02000433 RID: 1075
		[Token(Token = "0x2000433")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E306C", Offset = "0x10E306C")]
		private sealed class <>c__DisplayClass7_0
		{
			// Token: 0x06001BD6 RID: 7126 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BD6")]
			[Address(RVA = "0x1F87174", Offset = "0x1F87174", VA = "0x7BBC787174")]
			public <>c__DisplayClass7_0()
			{
			}

			// Token: 0x06001BD7 RID: 7127 RVA: 0x0000BD30 File Offset: 0x00009F30
			[Token(Token = "0x6001BD7")]
			[Address(RVA = "0x1F87438", Offset = "0x1F87438", VA = "0x7BBC787438")]
			internal bool <UpdateComponentFlags>b__0(VolumeEffectFieldFlags s)
			{
				return default(bool);
			}

			// Token: 0x04001440 RID: 5184
			[Token(Token = "0x4001440")]
			[FieldOffset(Offset = "0x10")]
			public FieldInfo pi;
		}

		// Token: 0x02000434 RID: 1076
		[Token(Token = "0x2000434")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E307C", Offset = "0x10E307C")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06001BD9 RID: 7129 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BD9")]
			[Address(RVA = "0x1F8738C", Offset = "0x1F8738C", VA = "0x7BBC78738C")]
			public <>c()
			{
			}

			// Token: 0x06001BDA RID: 7130 RVA: 0x0000BD48 File Offset: 0x00009F48
			[Token(Token = "0x6001BDA")]
			[Address(RVA = "0x1F87394", Offset = "0x1F87394", VA = "0x7BBC787394")]
			internal bool <GetFieldNames>b__8_0(VolumeEffectFieldFlags r)
			{
				return default(bool);
			}

			// Token: 0x06001BDB RID: 7131 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6001BDB")]
			[Address(RVA = "0x1F873C0", Offset = "0x1F873C0", VA = "0x7BBC7873C0")]
			internal string <GetFieldNames>b__8_1(VolumeEffectFieldFlags r)
			{
				return null;
			}

			// Token: 0x04001441 RID: 5185
			[Token(Token = "0x4001441")]
			[FieldOffset(Offset = "0x0")]
			public static readonly VolumeEffectComponentFlags.<>c <>9;

			// Token: 0x04001442 RID: 5186
			[Token(Token = "0x4001442")]
			[FieldOffset(Offset = "0x8")]
			public static Func<VolumeEffectFieldFlags, bool> <>9__8_0;

			// Token: 0x04001443 RID: 5187
			[Token(Token = "0x4001443")]
			[FieldOffset(Offset = "0x10")]
			public static Func<VolumeEffectFieldFlags, string> <>9__8_1;
		}
	}
}
