﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Il2CppDummyDll;
using UnityEngine;

namespace AmplifyColor
{
	// Token: 0x02000429 RID: 1065
	[Token(Token = "0x2000429")]
	[Serializable]
	public class VolumeEffectComponent
	{
		// Token: 0x06001BA6 RID: 7078 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BA6")]
		[Address(RVA = "0x1F844DC", Offset = "0x1F844DC", VA = "0x7BBC7844DC")]
		public VolumeEffectComponent(string name)
		{
		}

		// Token: 0x06001BA7 RID: 7079 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BA7")]
		[Address(RVA = "0x1F860D0", Offset = "0x1F860D0", VA = "0x7BBC7860D0")]
		public VolumeEffectField AddField(FieldInfo pi, Component c)
		{
			return null;
		}

		// Token: 0x06001BA8 RID: 7080 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BA8")]
		[Address(RVA = "0x1F860D8", Offset = "0x1F860D8", VA = "0x7BBC7860D8")]
		public VolumeEffectField AddField(FieldInfo pi, Component c, int position)
		{
			return null;
		}

		// Token: 0x06001BA9 RID: 7081 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BA9")]
		[Address(RVA = "0x1F863EC", Offset = "0x1F863EC", VA = "0x7BBC7863EC")]
		public void RemoveEffectField(VolumeEffectField field)
		{
		}

		// Token: 0x06001BAA RID: 7082 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BAA")]
		[Address(RVA = "0x1F84AF4", Offset = "0x1F84AF4", VA = "0x7BBC784AF4")]
		public VolumeEffectComponent(Component c, VolumeEffectComponentFlags compFlags)
		{
		}

		// Token: 0x06001BAB RID: 7083 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6001BAB")]
		[Address(RVA = "0x1F847A8", Offset = "0x1F847A8", VA = "0x7BBC7847A8")]
		public void UpdateComponent(Component c, VolumeEffectComponentFlags compFlags)
		{
		}

		// Token: 0x06001BAC RID: 7084 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BAC")]
		[Address(RVA = "0x1F84560", Offset = "0x1F84560", VA = "0x7BBC784560")]
		public VolumeEffectField FindEffectField(string fieldName)
		{
			return null;
		}

		// Token: 0x06001BAD RID: 7085 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BAD")]
		[Address(RVA = "0x1F86464", Offset = "0x1F86464", VA = "0x7BBC786464")]
		public static FieldInfo[] ListAcceptableFields(Component c)
		{
			return null;
		}

		// Token: 0x06001BAE RID: 7086 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6001BAE")]
		[Address(RVA = "0x1F865EC", Offset = "0x1F865EC", VA = "0x7BBC7865EC")]
		public string[] GetFieldNames()
		{
			return null;
		}

		// Token: 0x0400142B RID: 5163
		[Token(Token = "0x400142B")]
		[FieldOffset(Offset = "0x10")]
		public string componentName;

		// Token: 0x0400142C RID: 5164
		[Token(Token = "0x400142C")]
		[FieldOffset(Offset = "0x18")]
		public List<VolumeEffectField> fields;

		// Token: 0x0200042A RID: 1066
		[Token(Token = "0x200042A")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E301C", Offset = "0x10E301C")]
		private sealed class <>c__DisplayClass7_0
		{
			// Token: 0x06001BAF RID: 7087 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BAF")]
			[Address(RVA = "0x1F8645C", Offset = "0x1F8645C", VA = "0x7BBC78645C")]
			public <>c__DisplayClass7_0()
			{
			}

			// Token: 0x06001BB0 RID: 7088 RVA: 0x0000BCD0 File Offset: 0x00009ED0
			[Token(Token = "0x6001BB0")]
			[Address(RVA = "0x1F867E0", Offset = "0x1F867E0", VA = "0x7BBC7867E0")]
			internal bool <UpdateComponent>b__0(VolumeEffectField s)
			{
				return default(bool);
			}

			// Token: 0x0400142D RID: 5165
			[Token(Token = "0x400142D")]
			[FieldOffset(Offset = "0x10")]
			public VolumeEffectFieldFlags fieldFlags;
		}

		// Token: 0x0200042B RID: 1067
		[Token(Token = "0x200042B")]
		[Attribute(Name = "CompilerGeneratedAttribute", RVA = "0x10E302C", Offset = "0x10E302C")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06001BB2 RID: 7090 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6001BB2")]
			[Address(RVA = "0x1F86750", Offset = "0x1F86750", VA = "0x7BBC786750")]
			public <>c()
			{
			}

			// Token: 0x06001BB3 RID: 7091 RVA: 0x0000BCE8 File Offset: 0x00009EE8
			[Token(Token = "0x6001BB3")]
			[Address(RVA = "0x1F86758", Offset = "0x1F86758", VA = "0x7BBC786758")]
			internal bool <ListAcceptableFields>b__9_0(FieldInfo f)
			{
				return default(bool);
			}

			// Token: 0x06001BB4 RID: 7092 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6001BB4")]
			[Address(RVA = "0x1F867B4", Offset = "0x1F867B4", VA = "0x7BBC7867B4")]
			internal string <GetFieldNames>b__10_0(VolumeEffectField r)
			{
				return null;
			}

			// Token: 0x0400142E RID: 5166
			[Token(Token = "0x400142E")]
			[FieldOffset(Offset = "0x0")]
			public static readonly VolumeEffectComponent.<>c <>9;

			// Token: 0x0400142F RID: 5167
			[Token(Token = "0x400142F")]
			[FieldOffset(Offset = "0x8")]
			public static Func<FieldInfo, bool> <>9__9_0;

			// Token: 0x04001430 RID: 5168
			[Token(Token = "0x4001430")]
			[FieldOffset(Offset = "0x10")]
			public static Func<VolumeEffectField, string> <>9__10_0;
		}
	}
}
