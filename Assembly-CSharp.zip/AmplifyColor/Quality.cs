﻿using System;
using Il2CppDummyDll;

namespace AmplifyColor
{
	// Token: 0x02000424 RID: 1060
	[Token(Token = "0x2000424")]
	public enum Quality
	{
		// Token: 0x04001409 RID: 5129
		[Token(Token = "0x4001409")]
		Mobile,
		// Token: 0x0400140A RID: 5130
		[Token(Token = "0x400140A")]
		Standard
	}
}
