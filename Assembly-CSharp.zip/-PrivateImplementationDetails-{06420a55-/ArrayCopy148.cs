﻿using System;
using System.Runtime.InteropServices;
using Il2CppDummyDll;

namespace <PrivateImplementationDetails>{06420a55-ec7c-4dab-a57c-27256ec51107}
{
	// Token: 0x02002C20 RID: 11296
	[Token(Token = "0x2002C20")]
	[StructLayout(3, CharSet = CharSet.Auto)]
	internal class ArrayCopy148
	{
		// Token: 0x0600F94F RID: 63823 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x600F94F")]
		[Address(RVA = "0x1F824C4", Offset = "0x1F824C4", VA = "0x7BBC7824C4")]
		public ArrayCopy148()
		{
		}

		// Token: 0x04011D93 RID: 73107
		[Token(Token = "0x4011D93")]
		[MetadataOffset(Offset = "0x769848")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		internal static ArrayCopy148.$ArrayType$151 $$field-0;

		// Token: 0x02002C21 RID: 11297
		[Token(Token = "0x2002C21")]
		[StructLayout(2)]
		private struct $ArrayType$151
		{
		}
	}
}
